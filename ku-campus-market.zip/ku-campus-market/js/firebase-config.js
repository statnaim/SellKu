// Firebase Console > Project settings > Your apps > SDK setup.
// Replace these placeholder values with your own Firebase web app configuration.
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_FIREBASE_APP_ID"
};
export const firebaseConfigured = !Object.values(firebaseConfig).some(v => String(v).includes('YOUR_'));
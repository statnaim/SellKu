# KU Campus Market

Student-focused campus marketplace starter for Khulna University. UI language defaults to Bangla. Frontend uses HTML/CSS/vanilla JavaScript modules and Firebase modular SDK.

## Current implemented scope
- Responsive homepage, category browsing, search, category filtering, sorting, dark mode.
- Firebase email/password registration/login, email verification, password reset, logout.
- Firestore listing feed (approved only), listing submission with image upload, pending status, owner listing overview.
- Wishlist storage per user, product details modal, basic share-link copy.
- Firestore/Storage rules, indexes, Firebase Hosting config, starter Cloud Functions.

## Important limitations
This is a functional starter, not a claim that every item in the large specification is complete. Internal real-time chat UI, complete admin moderation screens, student-ID review UI, push notifications, advanced search, full English localization, account deletion orchestration, rate limiting, and end-to-end security tests still need implementation before a public production launch. Do not advertise those as finished. Have the rules reviewed and tested in Firebase Emulator Suite before public launch.

## 1. Requirements
- Node.js 20 or newer
- Firebase CLI: `npm install -g firebase-tools`
- A Firebase project
- VS Code or another editor

## 2. Firebase setup
1. Open Firebase Console and create a project.
2. Add a Web App and copy its config into `js/firebase-config.js`.
3. Authentication → Sign-in method → enable Email/Password.
4. Authentication → Settings → Authorized domains: add your deployment domain.
5. Firestore Database → create database, then deploy the included rules/indexes.
6. Storage → set up a bucket and deploy `storage.rules`.
7. Ensure billing/plan supports the Firebase services you enable; current Firebase Storage setup and Cloud Functions may require a billing-enabled project depending on current Firebase policies.
8. Configure Functions secrets/params and review `functions/index.js` before deployment. Never commit service-account keys.

## 3. Run locally
From this directory:
```bash
npm install -g firebase-tools
firebase login
firebase use --add
firebase emulators:start --only hosting,auth,firestore,storage,functions
```
Or for a simple static preview use VS Code Live Server. ES modules should be served over HTTP, not opened as `file://`.

## 4. Deploy
```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
firebase deploy --only hosting
```
Deploy functions separately after reviewing bootstrap configuration:
```bash
cd functions && npm install && cd ..
firebase deploy --only functions
```

## 5. Create the first administrator safely
The example `bootstrapFirstAdmin` callable is a one-time bootstrap pattern and must be configured with a trusted email through the deployment environment. Restrict and test it carefully, invoke only from the trusted account, verify the claim in Firebase Auth, then disable/remove the bootstrap endpoint. A callable function is not safe merely because it is hard to guess. Never add `admin:true` from client code. For a production system, prefer a tightly controlled admin provisioning script run by a trusted operator.

## 6. Firestore model (starter)
- `users/{uid}`: public-ish profile fields and email verification snapshot. UID is authoritative.
- `listings/{listingId}`: title, category, price, condition, description, imageUrls, hall, ownerUid, status, timestamps. Only approved listings are public.
- `wishlists/{uid}`: listingIds array for the signed-in user.
- `conversations/{id}/messages/{messageId}`: intended chat schema; UI is not yet wired.
- `notifications/{id}`: ownerUid, type, title, body, read, createdAt.
- `reports/{id}`: reporterUid, listing/user target, reason, status.
- `studentVerifications/{uid}`: private admin-reviewed verification record; do not store public URLs for student documents.
- `categories/{id}`, `halls/{id}`, `applicationSettings/{id}`, `adminAuditLogs/{id}`: managed reference/config/audit data.

## 7. Security notes
- Firebase web config is client-visible by design; it is not a service-account secret. Protect data with Rules, App Check where suitable, validation, and server-controlled custom claims.
- Rules are a starting point and require emulator tests. Verify document schemas carefully before real users.
- Listing image objects are currently readable by URL to support public product images. Never put student verification documents in `listingImages`.
- The student verification Storage rule is deliberately not a full admin-review workflow. Build server-authorized access before collecting ID documents.
- Direct seller/buyer transaction only: inspect items in a public place and avoid advance payment. Marketplace activity cannot be guaranteed scam-free.
- Firestore basic queries are not unrestricted full-text search. Add a search provider (e.g. Algolia/Typesense) for advanced search.
- Firebase quotas, billing and product availability can change. Configure budget alerts and backups.

## 8. Testing checklist
- [ ] Register, confirm email, login, logout, password reset.
- [ ] Unverified users cannot submit listings.
- [ ] Authenticated user can upload 1–5 valid images under 5 MB each.
- [ ] Invalid MIME types, oversized images and missing required fields are rejected.
- [ ] New listing stays pending and is not visible in public feed.
- [ ] A normal user cannot change listing status to approved or change ownerUid.
- [ ] User A cannot read User B's wishlist or profile private fields.
- [ ] User A cannot read messages in a conversation they are not part of.
- [ ] Non-admin cannot read student verification documents or write admin audit logs.
- [ ] Admin claim can only be granted through trusted server process.
- [ ] Test all rules using Firebase Emulator Suite and `@firebase/rules-unit-testing`.
- [ ] Test mobile layout, keyboard navigation, error states, empty states, account deletion, reports, and backup restore.

## 9. GitHub Pages option
GitHub Pages can host the static frontend, but it cannot run Cloud Functions or provide a secure backend. Keep Firebase security rules enabled. Firebase Hosting is the recommended default for this project.

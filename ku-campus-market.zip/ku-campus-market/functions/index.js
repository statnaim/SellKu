const { onCall, HttpsError } = require('firebase-functions/v2/https');
const { onDocumentCreated } = require('firebase-functions/v2/firestore');
const { initializeApp } = require('firebase-admin/app');
const { getAuth } = require('firebase-admin/auth');
const { getFirestore, FieldValue } = require('firebase-admin/firestore');
initializeApp();
const db = getFirestore();

// Run only by a trusted project owner. Never expose this callable to normal users.
// Bootstrap the first admin by setting KU_BOOTSTRAP_ADMIN_EMAIL in function config/params,
// deploy, call once as that verified account, then remove/disable the bootstrap function.
exports.bootstrapFirstAdmin = onCall(async (request) => {
  if (!request.auth || !request.auth.token.email_verified) throw new HttpsError('permission-denied','Verified sign-in required.');
  const configuredEmail = process.env.KU_BOOTSTRAP_ADMIN_EMAIL;
  if (!configuredEmail || request.auth.token.email !== configuredEmail) throw new HttpsError('permission-denied','Not authorized for bootstrap.');
  const marker = await db.doc('_private/adminBootstrap').get();
  if (marker.exists) throw new HttpsError('failed-precondition','Admin bootstrap has already been used.');
  await getAuth().setCustomUserClaims(request.auth.uid,{admin:true});
  await db.doc('_private/adminBootstrap').set({uid:request.auth.uid,createdAt:FieldValue.serverTimestamp()});
  return {ok:true,message:'Admin claim set. Sign out and sign in again.'};
});

// When a listing is created, write an owner notification. Approval remains admin-only via Rules.
exports.notifyListingSubmitted = onDocumentCreated('listings/{listingId}', async (event) => {
  const data = event.data?.data(); if (!data || !data.ownerUid) return;
  await db.collection('notifications').add({ownerUid:data.ownerUid,type:'listing_submitted',listingId:event.params.listingId,title:'বিজ্ঞাপন জমা হয়েছে',body:'তোমার বিজ্ঞাপন অনুমোদনের জন্য অপেক্ষা করছে।',read:false,createdAt:FieldValue.serverTimestamp()});
});